import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Output() page = new EventEmitter();
  show: boolean = true;
  menu1: boolean = false;
  constructor() { }
  setMenu(){
    this.menu1 = true;
  }
  ngOnInit(): void {
  }


}
