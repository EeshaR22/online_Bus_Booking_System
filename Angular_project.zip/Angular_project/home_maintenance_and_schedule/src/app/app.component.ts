import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title: string = 'WELCOME';
  arr = [{name:"user1"},{name:"user2"},{name:"user3"}];
  currentPage = "home"
  pageName(event: any){
    this.currentPage = event;
    console.log(event);
  }
}
