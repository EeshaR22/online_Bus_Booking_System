import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {
  title = 'dataTable';
 
  dtOptions: DataTables.Settings = {};
  posts: any;
  
  

  constructor(private http: HttpClient) {
    this.posts =[{date: "apr 19,2022",id: 1,bus: "5001|Economy",location: "Banglore to Anantapur" ,departure:"5.00PM",availability: "4",price: 300},
    {date: "apr 19,2022",id: 2,bus: "5001|Economy",location : "Banglore to Anantapur" ,departure:"5.10PM",availability: "3",price: 400},
    {date: "apr 20,2022",id: 3,bus: "5002|Economy",location : "Hyderabad to Anantapur", departure:"6.30PM",availability: "13",price: 200},
    {date: "apr 20,2022",id: 4,bus: "5002|Economy",location : "Hyderabad  to Anantapur", departure:"6.10PM",availability: "6",price: 786},
    {date: "apr 20,2022",id: 5,bus: "5003|Economy",location : " visakhapatnam to Hyderabad", departure:"7.10PM",availability: "10",price: 432},
    {date: "apr 20,2022",id: 6,bus: "5003|Economy",location : " visakhapatnam to vijayawada", departure:"7.30PM",availability: "6",price: 376},
    {date: "apr 21,2022",id: 7,bus: "5003|Economy",location : "Banglore to Nellore", departure:"8.00PM",availability: "11",price: 543}];
  


  }
 
  ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 5,
      processing: true
    };
  }

}
