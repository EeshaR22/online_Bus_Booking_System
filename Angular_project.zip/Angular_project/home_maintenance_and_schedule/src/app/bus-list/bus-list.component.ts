import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrls: ['./bus-list.component.scss'],
})
export class BusListComponent implements OnInit, OnChanges {
  title = 'buslist';

  dtOptions: DataTables.Settings = {};
  posts: any;

  busList: any;

  editCache: { [key: string]: any } = {};

  constructor(private http: HttpClient) {
    this.busList = [
      { id: 1, busNumber: '5001', busName: 'abc' },
      { id: 2, busNumber: '5002', busName: 'efg' },
      { id: 3, busNumber: '5003', busName: 'ijk' },
      { id: 4, busNumber: '5004', busName: 'mno' },
    ];
  }

  editBus(id: Number) {
    this.editCache[id.toString()].edit = true;
  }

  cancelEditingBus(id: Number) {
    this.editCache[id.toString()].edit = false;
  }

  saveBusEdit(id: Number) {
    const index = this.busList.findIndex((bus: { id: any }) => bus.id === id);
    let busItem = {
      busNumber: this.editCache[id.toString()].controller.busNumber,
      busName: this.editCache[id.toString()].controller.busName,
    };
    Object.assign(this.busList[index], busItem);
    this.editCache[id.toString()].edit = false;
  }

  deleteBus(id: Number) {
    this.busList = this.busList.filter(
      (bus: { id: string | number; busNumber: any; busName: any }) => {
        return bus.id != id;
      }
    );
    delete this.editCache[id.toString()];
  }

  addBus() {
    if (
      !this.busList.every(
        (bus: { id: string | number; busNumber: any; busName: any }) =>
          this.editCache[bus.id].edit === false
      )
    ) {
      alert('Save or Cancel the existing bus details first');
      return;
    }
    let busId = Math.round(Math.random() * 1000 + 1);
    // TODO:  make API call and get bus id here currently using random bus id
    this.editCache[busId.toString()] = {
      controller: {
        busNumber: '',
        busName: '',
      },
      edit: true,
    };
    this.busList.push({
      id: busId,
      busNumber: '',
      busName: '',
    });
  }

  ngOnInit() {
    this.busList.forEach(
      (bus: { id: string | number; busNumber: any; busName: any }) => {
        this.editCache[bus.id] = {
          controller: {
            busNumber: bus.busNumber,
            busName: bus.busName,
          },
          edit: false,
        };
      }
    );

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 5,
      processing: true,
    };
  }

  ngOnChanges(changes: SimpleChanges): void {}
}
