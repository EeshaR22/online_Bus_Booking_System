import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-location-list',
  templateUrl: './location-list.component.html',
  styleUrls: ['./location-list.component.scss'],
})
export class LocationListComponent implements OnInit {
  title = 'locationlist';

  dtOptions: DataTables.Settings = {};

  locationList: any;

  editCache: { [key: string]: any } = {};

  constructor(private http: HttpClient) {
    this.locationList = [
      {
        id: 1,
        terminal: 'North terminal',
        city: 'Mumbai',
        province: 'Sample1',
      },
      { id: 2, terminal: 'South terminal', city: 'Pune', province: 'Sample2' },
      { id: 3, terminal: 'East terminal', city: 'Nagpur', province: 'Sample3' },
      {
        id: 4,
        terminal: 'West terminal',
        city: 'Ahmedabad',
        province: 'Sample14',
      },
    ];
  }

  editlocation(id: Number) {
    this.editCache[id.toString()].edit = true;
  }

  cancelEditinglocation(id: Number) {
    this.editCache[id.toString()].edit = false;
  }

  savelocationEdit(id: Number) {
    const index = this.locationList.findIndex(
      (location: { id: any }) => location.id === id
    );
    let locationItem = {
      terminal: this.editCache[id.toString()].controller.terminal,
      city: this.editCache[id.toString()].controller.city,
      province: this.editCache[id.toString()].controller.province,
    };
    Object.assign(this.locationList[index], locationItem);
    this.editCache[id.toString()].edit = false;
  }

  deletelocation(id: Number) {
    this.locationList = this.locationList.filter(
      (location: {
        id: string | number;
        terminal: any;
        city: any;
        province: any;
      }) => {
        return location.id != id;
      }
    );
    delete this.editCache[id.toString()];
  }

  addLocation() {
    if (
      !this.locationList.every(
        (location: {
          id: string | number;
          terminal: any;
          city: any;
          province: any;
        }) => this.editCache[location.id].edit === false
      )
    ) {
      alert('Save or Cancel the existing bus details first');
      return;
    }
    let locationId = Math.round(Math.random() * 1000 + 1);
    // TODO:  make API call and get bus id here currently using random bus id
    this.editCache[locationId.toString()] = {
      controller: {
        terminal: '',
        city: '',
        province: '',
      },
      edit: true,
    };
    this.locationList.push({
      id: locationId,
      terminal: '',
      city: '',
      province: '',
    });
  }

  ngOnInit() {
    this.locationList.forEach(
      (location: {
        id: string | number;
        terminal: any;
        city: any;
        province: any;
      }) => {
        this.editCache[location.id] = {
          controller: {
            terminal: location.terminal,
            city: location.city,
            province: location.province,
          },
          edit: false,
        };
      }
    );

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 5,
      processing: true,
    };
  }

  ngOnChanges(changes: SimpleChanges): void {}
}
