package com.mphasis.bus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.bus.model.BusBookedList;
import com.project.bus.model.BusList;
import com.project.bus.model.BusSchedule;
import com.project.bus.model.LocationList;
import com.project.bus.model.User;
import com.project.bus.repository.BusBookedListRepository;



@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class BusBookingApplicationTests {
	
	@Autowired
	BusBookedListRepository repo;

	@Test
	@Order(1)
	public void contextLoads() {
		BusBookedList b = new BusBookedList();
		b.setId(1);
		b.setRef_No("20220418");
		b.setName("Economy");
		b.setQty("2");
		b.setAmount("500");
		b.setStatus("Paid");
		repo.save(b);
		assertNotNull(repo.findById(1L).get());
	}
	
	@Test
	@Order(2)
	public void getAllbookedList() {
		List<BusBookedList> list = repo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	@Order(3)
	public void testUpdate() {
		BusBookedList bus = repo.findById(1L).get();
		bus.setName("Tour");
		repo.save(bus);
		assertNotEquals("Economy", repo.findById(1L).get().getName());
	}
	
	@Test
	@Order(4)
	public void testDeleteBookedList() {
		repo.deleteById(2L);
		assertThat(repo.existsById(2L)).isFalse();
	}

}
