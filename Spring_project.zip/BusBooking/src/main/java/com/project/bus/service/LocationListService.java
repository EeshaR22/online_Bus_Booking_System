package com.project.bus.service;

import java.util.List;

import com.project.bus.model.LocationList;

public interface LocationListService {
	LocationList saveLocationList(LocationList locationlist);

	List<LocationList> getAllLocation();

	LocationList getLocationById(long id);

	LocationList updateLocation(LocationList locationlist, long id);

	void deleteLocation(long id);
}