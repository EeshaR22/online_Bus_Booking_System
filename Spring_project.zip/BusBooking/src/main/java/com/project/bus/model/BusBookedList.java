package com.project.bus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BusBooked_List")
public class BusBookedList {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "Ref_No")
	private String Ref_No;

	@Column(name = "Name")
	private String Name;

	@Column(name = "Qty")
	private String Qty;
	
	@Column(name = "Amount")
	private String Amount;

	@Column(name = "Status")
	private String Status;

	public BusBookedList() {

	}

	public BusBookedList(long id, String Ref_No, String Name, String Qty, String Amount, String Status) {
		super();
		this.id = id;
		this.Ref_No = Ref_No;
		this.Name = Name;
		this.Qty = Qty;
		this.Amount = Amount;
		this.Status = Status;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRef_No() {
		return Ref_No;
	}

	public void setRef_No(String ref_No) {
		Ref_No = ref_No;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getQty() {
		return Qty;
	}

	public void setQty(String qty) {
		Qty = qty;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

}
