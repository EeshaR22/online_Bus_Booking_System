package com.project.bus.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.bus.exception.ResourceNotFoundException;
import com.project.bus.model.BusBookedList;
import com.project.bus.repository.BusBookedListRepository;

@Service
public class BusBookedListImpl implements BusBookedListService {

	private BusBookedListRepository busBookedListRepository;

	public BusBookedListImpl(BusBookedListRepository busBookedListRepository) {
		super();
		this.busBookedListRepository = busBookedListRepository;
	}

	@Override
	public BusBookedList saveBusBookedList(BusBookedList busBookedList) {
		return busBookedListRepository.save(busBookedList);
	}

	@Override
	public List<BusBookedList> getAllBookedList() {
		return busBookedListRepository.findAll();
	}

	@Override
	public BusBookedList getBookedListById(long id) {
		return busBookedListRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("BookedList", "Id", id));

	}

	@Override
	public BusBookedList updateBookedList(BusBookedList busBookedList, long id) {

		BusBookedList busBookedListDetails = busBookedListRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("BookedList", "Id", id));

		busBookedListDetails.setRef_No(busBookedList.getRef_No());
		busBookedListDetails.setName(busBookedList.getName());
		busBookedListDetails.setQty(busBookedList.getQty());
		busBookedListDetails.setAmount(busBookedList.getAmount());
		busBookedListDetails.setStatus(busBookedList.getStatus());

		busBookedListRepository.save(busBookedListDetails);
		return busBookedListDetails;
	}

	@Override
	public void deleteBookedList(long id) {

		busBookedListRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("BookedList", "Id", id));
		busBookedListRepository.deleteById(id);
	}

}