package com.project.bus.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; 
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bus.model.LocationList;
import com.project.bus.service.LocationListService;

@RestController
@RequestMapping("/api/v1")
public class LocationListController {

	private LocationListService locationlistService;

	public LocationListController(LocationListService locationlistService) {
		super();
		this.locationlistService = locationlistService;
	}

	@PostMapping("/locations")
	public ResponseEntity<LocationList> saveLocationList(@RequestBody LocationList locationlist) {
		return new ResponseEntity<LocationList>(locationlistService.saveLocationList(locationlist),
				HttpStatus.CREATED);
	}

	@GetMapping("/locations")
	public List<LocationList> getAllList() {
		return locationlistService.getAllLocation();
	}

	@GetMapping("/locations/{id}")
	public ResponseEntity<LocationList> getLocationeById(@PathVariable("id") int locationId) {
		return new ResponseEntity<LocationList>(locationlistService.getLocationById(locationId), HttpStatus.OK);
	}

	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/locations/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LocationList> updateLocation(@PathVariable("id") int id,
			@RequestBody LocationList locationlist) {
		return new ResponseEntity<LocationList>(locationlistService.updateLocation(locationlist, id),
				HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/locations/{id}")
	public ResponseEntity<String> deleteLocation(@PathVariable("id") int id) {

		locationlistService.deleteLocation(id);

		return new ResponseEntity<String>("Location deleted successfully!.", HttpStatus.OK);
	}

}