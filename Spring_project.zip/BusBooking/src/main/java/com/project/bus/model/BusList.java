package com.project.bus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BusList")
public class BusList {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "Bus_Number")
	private int Bus_Number;

	@Column(name = "Bus_Name")
	private String Bus_Name;

	public BusList() {
		
	}

	public BusList(int Bus_Number, String Bus_Name) {
		super();
		
		this.Bus_Number = Bus_Number;
		this.Bus_Name = Bus_Name;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getBus_Number() {
		return Bus_Number;
	}

	public void setBus_Number(int bus_Number) {
		Bus_Number = bus_Number;
	}

	public String getBus_Name() {
		return Bus_Name;
	}

	public void setBus_Name(String bus_Name) {
		Bus_Name = bus_Name;
	}
	
}