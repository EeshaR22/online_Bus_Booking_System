package com.project.bus.service;

import org.springframework.stereotype.Service;

import com.project.bus.model.AdminLogin;
import com.project.bus.repository.AdminLoginRepository;

@Service
public class AdminLoginImpl implements AdminLoginService {

	private AdminLoginRepository adminLoginRepository;

	public AdminLoginImpl(AdminLoginRepository adminLoginRepository) {
		super();
		this.adminLoginRepository = adminLoginRepository;
	}

	@Override
	public AdminLogin saveAdmin(AdminLogin adminLogin) {
		return adminLoginRepository.save(adminLogin);
	}
}
