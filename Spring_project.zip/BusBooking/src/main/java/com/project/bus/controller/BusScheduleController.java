package com.project.bus.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bus.model.BusSchedule;
import com.project.bus.service.BusScheduleService;

@RestController
@RequestMapping("/api/v1")
public class BusScheduleController {

	private BusScheduleService busScheduleService;

	public BusScheduleController(BusScheduleService busScheduleService) {
		super();
		this.busScheduleService = busScheduleService;
	}

	@PostMapping("/schedule")
	public ResponseEntity<BusSchedule> saveBusSchedule(@RequestBody BusSchedule busSchedule) {
		return new ResponseEntity<BusSchedule>(busScheduleService.saveBusSchedule(busSchedule),
				HttpStatus.CREATED);
	}

	@GetMapping("/schedule")
	public List<BusSchedule> getAllSchedule() {
		return busScheduleService.getAllSchedule();
	}

	@GetMapping("/schedule/{id}")
	public ResponseEntity<BusSchedule> getScheduleById(@PathVariable("id") long busId) {
		return new ResponseEntity<BusSchedule>(busScheduleService.getScheduleById(busId), HttpStatus.OK);
	}

	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/schedule/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BusSchedule> updateSchedule(@PathVariable("id") long id,
			@RequestBody BusSchedule busSchedule) {
		return new ResponseEntity<BusSchedule>(busScheduleService.updateSchedule(busSchedule, id),
				HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/schedule/{id}")
	public ResponseEntity<String> deleteSchedule(@PathVariable("id") long id) {

		busScheduleService.deleteSchedule(id);

		return new ResponseEntity<String>("Schedule deleted successfully!.", HttpStatus.OK);
	}

}