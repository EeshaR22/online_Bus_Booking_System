package com.project.bus.service;

import java.util.List;

import com.project.bus.model.BusList;

public interface BusListService {
		BusList saveBusList(BusList buslist);		
		List<BusList> getAllBusList();
		BusList getBusListById(long id);
		BusList updateBusList(BusList buslist, long id);
		void deleteBusList(Long id);
}
