package com.project.bus.service;

import java.util.List;

import com.project.bus.model.BusBookedList;

public interface BusBookedListService {
	BusBookedList saveBusBookedList(BusBookedList busBookedList);

	List<BusBookedList> getAllBookedList();

	BusBookedList getBookedListById(long id);

	BusBookedList updateBookedList(BusBookedList busBookedList, long id);

	void deleteBookedList(long id);
}