package com.project.bus.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.bus.exception.ResourceNotFoundException;
import com.project.bus.model.BusSchedule;
import com.project.bus.repository.BusScheduleRepository;

@Service
public class BusScheduleImpl implements BusScheduleService {

	private BusScheduleRepository busScheduleRepository;

	public BusScheduleImpl(BusScheduleRepository busScheduleRepository) {
		super();
		this.busScheduleRepository = busScheduleRepository;
	}

	@Override
	public BusSchedule saveBusSchedule(BusSchedule busSchedule) {
		return busScheduleRepository.save(busSchedule);
	}

	@Override
	public List<BusSchedule> getAllSchedule() {
		return busScheduleRepository.findAll();
	}

	@Override
	public BusSchedule getScheduleById(long id) {
		return busScheduleRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Schedule", "Id", id));

	}

	@Override
	public BusSchedule updateSchedule(BusSchedule busSchedule, long id) {

		BusSchedule busScheduleDetails = busScheduleRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Schedule", "Id", id));

		busScheduleDetails.setDate(busSchedule.getDate());
		busScheduleDetails.setBus(busSchedule.getBus());
		busScheduleDetails.setLocation(busSchedule.getLocation());
		busScheduleDetails.setDeparture(busSchedule.getDeparture());
		busScheduleDetails.setAvailability(busSchedule.getAvailability());
		busScheduleDetails.setPrice(busSchedule.getPrice());

		busScheduleRepository.save(busScheduleDetails);
		return busScheduleDetails;
	}

	@Override
	public void deleteSchedule(long id) {

		busScheduleRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Schedule", "Id", id));
		busScheduleRepository.deleteById(id);
	}

}