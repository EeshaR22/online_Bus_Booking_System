package com.project.bus.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bus.model.BusBookedList;
import com.project.bus.service.BusBookedListService;

@RestController
@RequestMapping("/api/v1")
public class BusBookedListController {

	private BusBookedListService busBookedListService;

	public BusBookedListController(BusBookedListService busBookedListService) {
		super();
		this.busBookedListService = busBookedListService;
	}

	@PostMapping("/BookedList")
	public ResponseEntity<BusBookedList> saveBusBookedList(@RequestBody BusBookedList busBookedList) {
		return new ResponseEntity<BusBookedList>(busBookedListService.saveBusBookedList(busBookedList),
				HttpStatus.CREATED);
	}

	@GetMapping("/BookedList")
	public List<BusBookedList> getAllBookedList() {
		return busBookedListService.getAllBookedList();
	}

	@GetMapping("/BookedList/{id}")
	public ResponseEntity<BusBookedList> getBookedListById(@PathVariable("id") long busId) {
		return new ResponseEntity<BusBookedList>(busBookedListService.getBookedListById(busId), HttpStatus.OK);
	}

	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/BookedList/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BusBookedList> updateBookedList(@PathVariable("id") long id,
			@RequestBody BusBookedList busBookedList) {
		return new ResponseEntity<BusBookedList>(busBookedListService.updateBookedList(busBookedList, id),
				HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/BookedList/{id}")
	public ResponseEntity<String> deleteBookedList(@PathVariable("id") long id) {

		busBookedListService.deleteBookedList(id);

		return new ResponseEntity<String>("BookedList deleted successfully!.", HttpStatus.OK);
	}

}