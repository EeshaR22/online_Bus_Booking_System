package com.project.bus.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bus.model.BusList;
import com.project.bus.service.BusListService;

@RestController
@RequestMapping("/api/v1")
public class BusListController {

	private BusListService buslistService;

	public BusListController(BusListService buslistService) {
		super();
		this.buslistService = buslistService;
	}

	@PostMapping("/buslist")
	public ResponseEntity<BusList> saveBusList(@RequestBody BusList buslist) {
		return new ResponseEntity<BusList>(buslistService.saveBusList(buslist), HttpStatus.CREATED);
	}

	@GetMapping("/buslist")
	public List<BusList> getAllBusList() {
		return buslistService.getAllBusList();
	}

	@GetMapping("/buslist/{id}")
	public ResponseEntity<BusList> getBusListById(@PathVariable("id") long buslistId) {
		return new ResponseEntity<BusList>(buslistService.getBusListById(buslistId), HttpStatus.OK);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/buslist/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BusList> updateBusList(@PathVariable("id") long id, @RequestBody BusList buslist) {
		return new ResponseEntity<BusList>(buslistService.updateBusList(buslist, id), HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/buslist/{id}")
	public ResponseEntity<String> deleteBusList(@PathVariable("id") long id) {

		buslistService.deleteBusList(id);

		return new ResponseEntity<String>("Bus deleted successfully!.", HttpStatus.OK);
	}

}