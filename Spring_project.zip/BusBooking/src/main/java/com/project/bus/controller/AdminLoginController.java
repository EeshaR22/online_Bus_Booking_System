package com.project.bus.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bus.model.AdminLogin;
import com.project.bus.service.AdminLoginService;

@RestController
@RequestMapping("/api/v1")
public class AdminLoginController {

	private AdminLoginService adminLoginService;

	public AdminLoginController(AdminLoginService adminLoginService) {
		super();
		this.adminLoginService = adminLoginService;
	}

	@PostMapping("/adminlogin")
	public ResponseEntity<AdminLogin> saveAdmin(@RequestBody AdminLogin adminLogin) {
		return new ResponseEntity<AdminLogin>(adminLoginService.saveAdmin(adminLogin), HttpStatus.CREATED);
	}
}