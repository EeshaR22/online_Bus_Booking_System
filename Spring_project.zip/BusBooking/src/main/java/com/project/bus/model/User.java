package com.project.bus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class User {

	@Id
	
	@Column(name = "username")
	private String username;

	@Column(name = "name")
	private String name;

	@Column(name = "password")
	private String password;

	@Column(name = "Person")
	private String Person;

	@Column(name = "token")
	private String token;

	public User(String username, String name, String password, String Person, String token) {
		super();
		this.username = username;
		this.name = name;
		this.password = password;
		this.Person = Person;
		this.token = token;
	}

	public User() {

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPerson() {
		return Person;
	}

	public void setPerson(String role) {
		this.Person = Person;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}