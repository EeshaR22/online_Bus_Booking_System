package com.project.bus.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.bus.exception.ResourceNotFoundException;
import com.project.bus.model.BusList;
import com.project.bus.repository.BusListRepository;

@Service
public class BusListImpl implements BusListService {

	private BusListRepository buslistRepository;

	public BusListImpl(BusListRepository buslistRepository) {
		super();
		this.buslistRepository = buslistRepository;
	}

	@Override
	public BusList saveBusList(BusList buslist) {
		return buslistRepository.save(buslist);
	}

	@Override
	public List<BusList> getAllBusList() {
		return buslistRepository.findAll();
	}

	@Override
	public BusList getBusListById(long id) {
		return buslistRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Bus", "Id", id));

	}

	@Override
	public BusList updateBusList(BusList buslist, long id) {

		BusList buslistDetails = buslistRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Bus", "Id", id));

		buslistDetails.setBus_Number(buslist.getBus_Number());
		buslistDetails.setBus_Name(buslist.getBus_Name());

		buslistRepository.save(buslistDetails);
		return buslistDetails;
	}

	@Override
	public void deleteBusList(Long id) {

		buslistRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Bus", "Id", id));
		buslistRepository.deleteById(id);
	}

}