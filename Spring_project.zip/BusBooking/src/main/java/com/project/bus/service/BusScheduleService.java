package com.project.bus.service;

import java.util.List;

import com.project.bus.model.BusSchedule;

public interface BusScheduleService {
	BusSchedule saveBusSchedule(BusSchedule busSchedule);

	List<BusSchedule> getAllSchedule();

	BusSchedule getScheduleById(long id);

	BusSchedule updateSchedule(BusSchedule busSchedule, long id);

	void deleteSchedule(long id);
}