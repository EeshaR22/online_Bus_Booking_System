package com.project.bus.service;

import com.project.bus.model.AdminLogin;

public interface AdminLoginService {
	AdminLogin saveAdmin(AdminLogin adminLogin);

}