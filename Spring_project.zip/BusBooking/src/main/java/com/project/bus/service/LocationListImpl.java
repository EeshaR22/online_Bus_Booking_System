package com.project.bus.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.bus.exception.ResourceNotFoundException;
import com.project.bus.model.LocationList;
import com.project.bus.repository.LocationListRepository;

@Service
public class LocationListImpl implements LocationListService {

	private LocationListRepository locationlistRepository;

	public LocationListImpl(LocationListRepository locationlistRepository) {
		super();
		this.locationlistRepository = locationlistRepository;
	}

	@Override
	public LocationList saveLocationList(LocationList locationlist) {
		return locationlistRepository.save(locationlist);
	}

	@Override
	public List<LocationList> getAllLocation() {
		return locationlistRepository.findAll();
	}

	@Override
	public LocationList getLocationById(long id) {
		return locationlistRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Location", "Id", id));

	}

	@Override
	public LocationList updateLocation(LocationList locationlist, long id) {

		LocationList locationlistDetails = locationlistRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Location", "Id", id));

		locationlistDetails.setTerminal(locationlist.getTerminal());
		locationlistDetails.setCity(locationlist.getCity());
		locationlistDetails.setProvince(locationlist.getProvince());

		locationlistRepository.save(locationlistDetails);
		return locationlistDetails;
	}

	@Override
	public void deleteLocation(long id) {

		locationlistRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Location", "Id", id));
		locationlistRepository.deleteById(id);
	}

}