package com.project.bus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Location_List")
public class LocationList {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "Terminal")
	private String Terminal;

	@Column(name = "City")
	private String City;

	@Column(name = "Province")
	private String Province;

	public LocationList() {

	}

	public LocationList(int id, String Terminal, String City, String Province) {
		super();
		this.id = id;
		this.Terminal = Terminal;
		this.City = City;
		this.Province = Province;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTerminal() {
		return Terminal;
	}

	public void setTerminal(String terminal) {
		Terminal = terminal;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getProvince() {
		return Province;
	}

	public void setProvince(String province) {
		Province = province;
	}

}
