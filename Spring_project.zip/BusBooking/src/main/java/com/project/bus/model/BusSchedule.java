package com.project.bus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bus_Schedule")
public class BusSchedule {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "Date")
	private String Date;

	@Column(name = "Bus")
	private String Bus;

	@Column(name = "Location")
	private String Location;
	
	@Column(name = "Departure")
	private String Departure;
	
	@Column(name = "Availability")
	private String Availability;
	
	@Column(name = "Price")
	private String Price;

	public BusSchedule() {

	}

	public BusSchedule(long id, String Date, String Location, String Departure, String Availability, String Price) {
		super();
		this.id = id;
		this.Date = Date;
		this.Location = Location;
		this.Departure = Departure;
		this.Availability = Availability;
		this.Price = Price;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getBus() {
		return Bus;
	}

	public void setBus(String bus) {
		Bus = bus;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getDeparture() {
		return Departure;
	}

	public void setDeparture(String departure) {
		Departure = departure;
	}

	public String getAvailability() {
		return Availability;
	}

	public void setAvailability(String availability) {
		Availability = availability;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	
}
